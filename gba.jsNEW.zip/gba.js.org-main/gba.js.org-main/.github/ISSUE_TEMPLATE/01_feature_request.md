---
name: Feature request
about: Suggest features you'd like to see added
title: ''
labels: ''
assignees: ''

---

**Describe the feature you'd like added:** *A clear and concise description of your feature request.*


**Additional context:** *Add any other context or screenshots about the feature request here.*

